import { db } from "@/lib/db";
import { Prisma } from "@prisma/client";

export const leaveService = {

  async initializeYearlyBalance(userId: string, year: number, totalDays: number) {
    return await db.leaveBalance.upsert({
      where: { userId_year: { userId, year } },
      update: { totalDays },
      create: { userId, year, totalDays, usedDays: 0 }
    });
  },

  async createLeaveRecord(userId: string, data: {
    startDate: Date;
    endDate: Date;
    days: number;
  }) {
    const year = data.startDate.getFullYear();

    const balance = await db.leaveBalance.findUnique({
      where: { userId_year: { userId, year } }
    });

    if (!balance) {
      throw new Error(`${year} yılına ait bakiye yok.`);
    }

    const result = await db.$transaction([
      db.leave.create({
        data: {
          userId,
          startDate: data.startDate,
          endDate: data.endDate,
          days: data.days
        }
      }),
      db.leaveBalance.update({
        where: { id: balance.id },
        data: { usedDays: { increment: data.days } } 
      })
    ]);

    return result[0];
  },

  async deleteLeaveRecord(leaveId: string) {
    const leave = await db.leave.findUnique({ where: { id: leaveId } });
    if (!leave) throw new Error("İzin kaydı bulunamadı.");

    const year = leave.startDate.getFullYear();

    await db.$transaction([
      db.leave.delete({ where: { id: leaveId } }),
      db.leaveBalance.update({
        where: { userId_year: { userId: leave.userId, year } },
        data: { usedDays: { decrement: leave.days } } 
      })
    ]);

    return true;
  },

  async getPaginatedLeaves(page: number = 1, limit: number = 20) {
    const skip = (page - 1) * limit;

    const [data, totalCount] = await db.$transaction([
      db.leave.findMany({
        skip,
        take: limit,
        orderBy: { startDate: "desc" },
        include: { user: { select: { fullName: true, jobTitle: true } } }
      }),
      db.leave.count()
    ]);

    return { data, meta: { totalCount, page, limit, totalPages: Math.ceil(totalCount / limit) } };
  }
};